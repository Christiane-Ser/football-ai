const express = require("express");
const router = express.Router();
const footballservice = require('../services/football.service.js');
const { getPremierLeagueMatches } = require("../services/football.service");
const Match = require("../models/match");


router.get("/sync-matches", async (req, res) => {
  try {
    const data = await getPremierLeagueMatches();
    const matches = data.matches;

    await Match.deleteMany({});
    await Match.insertMany(matches);

    res.json({ message: "Matches synced", count: matches.length });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get("/matches", async (req, res) => {
  const matches = await Match.find();
  res.json(matches);
});

module.exports = router;
