const axios = require("axios");

const API_KEY = process.env.FOOTBALL_API_KEY;

const footballAPI = axios.create({
  baseURL: "https://api.football-data.org/v4",
  headers: { "X-Auth-Token": API_KEY }
});

const getPremierLeagueMatches = async () => {
  const response = await footballAPI.get("/competitions/PL/matches");
  return response.data;
};

module.exports = { getPremierLeagueMatches };

