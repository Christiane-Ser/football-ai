const express = require('express');
const dotenv = require('dotenv');
const footballRoutes = require('./routes/football.routes'); // Tes imports en premier

dotenv.config();

// 1. TU DOIS CRÉER L'APP ICI 
const app = express(); 

// 2. ENSUITE TU PEUX UTILISER L'APP
app.use(express.json()); 
app.use("/api/football", footballRoutes); // Cette ligne ne plantera plus

// 3. ENFIN LE LISTEN
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

